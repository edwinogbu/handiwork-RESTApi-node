const customerService = require('../services/customerService');

async function createCustomer(req, res) {
    try {
        const { firstName, lastName, email, password, phone, address } = req.body;
        const newCustomer = await customerService.createCustomer({ firstName, lastName, email, password, phone, address });
        res.status(201).json({ success: true, customer: newCustomer });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
}

async function getCustomerById(req, res) {
    try {
        const customerId = req.params.id;
        const customer = await customerService.getCustomerById(customerId);
        if (!customer) {
            res.status(404).json({ success: false, error: 'Customer not found' });
            return;
        }
        res.status(200).json({ success: true, customer });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
}

async function getAllCustomers(req, res) {
    try {
        const customers = await customerService.getAllCustomers();
        res.status(200).json({ success: true, customers });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
}

async function updateCustomer(req, res) {
    try {
        const customerId = req.params.id;
        const updates = req.body;
        const updatedCustomer = await customerService.updateCustomer(customerId, updates);
        res.status(200).json({ success: true, customer: updatedCustomer });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
}

async function deleteCustomer(req, res) {
    try {
        const customerId = req.params.id;
        await customerService.deleteCustomer(customerId);
        res.status(200).json({ success: true, message: 'Customer deleted successfully' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
}

module.exports = {
    createCustomer,
    getCustomerById,
    getAllCustomers,
    updateCustomer,
    deleteCustomer
};




// const CustomerService = require('../services/customerService');

// // Controller function to handle creating a new customer
// exports.createCustomer = async (req, res, next) => {
//     try {
//         const { firstName, lastName, email, phone, address, userId } = req.body;
//         const customerData = { firstName, lastName, email, phone, address, userId };
//         const customer = await CustomerService.createCustomer(customerData);
//         res.status(201).json({ success: true, data: customer });
//     } catch (error) {
//         res.status(500).json({ success: false, error: error.message });
//     }
// };

// // Controller function to handle getting a customer by ID
// exports.getCustomerById = async (req, res, next) => {
//     try {
//         const { id } = req.params;
//         const customer = await CustomerService.getCustomerById(id);
//         if (!customer) {
//             res.status(404).json({ success: false, message: 'Customer not found' });
//             return;
//         }
//         res.status(200).json({ success: true, data: customer });
//     } catch (error) {
//         res.status(500).json({ success: false, error: error.message });
//     }
// };

// // Controller function to handle updating a customer
// exports.updateCustomer = async (req, res, next) => {
//     try {
//         const { id } = req.params;
//         const updates = req.body;
//         const updatedCustomer = await CustomerService.updateCustomer(id, updates);
//         res.status(200).json({ success: true, data: updatedCustomer });
//     } catch (error) {
//         res.status(500).json({ success: false, error: error.message });
//     }
// };

// // Controller function to handle deleting a customer
// exports.deleteCustomer = async (req, res, next) => {
//     try {
//         const { id } = req.params;
//         await CustomerService.deleteCustomer(id);
//         res.status(200).json({ success: true, message: 'Customer deleted successfully' });
//     } catch (error) {
//         res.status(500).json({ success: false, error: error.message });
//     }
// };
