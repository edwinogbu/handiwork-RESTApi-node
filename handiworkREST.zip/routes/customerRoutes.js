const express = require('express');
const router = express.Router();
const userToken = require('./../middleware/userToken');
const customerController = require('../controllers/customerController');



router.post('/create', customerController.createCustomer);
router.get('/view/:id', customerController.getCustomerById);
router.get('/customers', customerController.getAllCustomers);
router.put('/update/:id', customerController.updateCustomer);
router.delete('/delete/:id', customerController.deleteCustomer);

module.exports = router;

// POST request to create a new customer
// router.post('/create', userToken, customerController.createCustomer);
// router.post('/create',  customerController.createCustomer);

// // GET request to get a customer by ID
// router.get('/view/:id', userToken, customerController.getCustomerById);

// // PUT request to update a customer by ID
// router.put('/update/:id', userToken, customerController.updateCustomer);

// // DELETE request to delete a customer by ID
// router.delete('/delete/:id', userToken, customerController.deleteCustomer);

// module.exports = router;
