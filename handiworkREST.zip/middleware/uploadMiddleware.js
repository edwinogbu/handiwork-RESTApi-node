//middlewares/uploadMiddleware.js
const multer = require('multer');
const path = require('path'); // Import the path module

// Set storage engine
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/'); // Define the destination folder for uploaded files
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + '-' + file.originalname); // Define the file name for the uploaded file
  }
});

// Init upload
const upload = multer({
  storage: storage,
  limits: {
    fileSize: 1024 * 1024 * 50 // Set file size limit (50MB in this example)
  },
  fileFilter: (req, file, cb) => {
    checkFileType(file, cb);
  }
}).single('file');

// Check file type
function checkFileType(file, cb) {
  // Allowed file extensions
  const filetypes = /jpeg|jpg|png|gif|pdf|doc|docx|txt|csv|gif|mp4/;
  // Check the file extension
  const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
  // Check the MIME type
  const mimetype = filetypes.test(file.mimetype);

  if (mimetype && extname) {
    return cb(null, true);
  } else {
    cb('Error: Invalid file type!');
  }
}

module.exports = upload;


// //middlewares/uploadMiddleware.js
// const multer = require('multer');

// // Set storage engine
// const storage = multer.diskStorage({
//   destination: (req, file, cb) => {
//     cb(null, 'uploads/'); // Define the destination folder for uploaded files
//   },
//   filename: (req, file, cb) => {
//     cb(null, Date.now() + '-' + file.originalname); // Define the file name for the uploaded file
//   }
// });

// // Init upload
// const upload = multer({
//   storage: storage,
//   limits: {
//     fileSize: 1024 * 1024 * 50 // Set file size limit (50MB in this example)
//   },
//   fileFilter: (req, file, cb) => {
//     checkFileType(file, cb);
//   }
// }).single('file');

// // Check file type
// function checkFileType(file, cb) {
//   // Allowed file extensions
//   const filetypes = /jpeg|jpg|png|gif|pdf|doc|docx|txt/;
//   // Check the file extension
//   const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
//   // Check the MIME type
//   const mimetype = filetypes.test(file.mimetype);

//   if (mimetype && extname) {
//     return cb(null, true);
//   } else {
//     cb('Error: Invalid file type!');
//   }
// }

// module.exports = upload;


// const multer = require('multer');
// const path = require('path');
// const fs = require('fs');

// // Set storage engine
// const storage = multer.diskStorage({
//   destination: (req, file, cb) => {
//     try {
//       const userId = req.user.id;
//       const folderName = req.params.folderName || 'defaultFolder'; // Provide a default folder name if not present
//       const userFolder = path.join(__dirname, `../uploads/${userId}`);
//       const folderPath = path.join(userFolder, folderName);

//       // Create the user folder if it doesn't exist
//       if (!fs.existsSync(userFolder)) {
//         fs.mkdirSync(userFolder);
//       }

//       // Create the folder if it doesn't exist
//       if (!fs.existsSync(folderPath)) {
//         fs.mkdirSync(folderPath);
//       }

//       cb(null, folderPath);
//     } catch (error) {
//       cb(error); // Pass the error to Multer
//     }
//   },
//   filename: (req, file, cb) => {
//     cb(null, file.originalname);
//   },
// });

// // Check file type
// function checkFileType(file, cb) {
//   // Allowed extensions
//   const filetypes = /jpeg|jpg|png|gif|pdf|doc|docx|txt/;
//   // Check the extension
//   const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
//   // Check the mime type
//   const mimetype = filetypes.test(file.mimetype);

//   if (mimetype && extname) {
//     return cb(null, true);
//   } else {
//     cb('Error: Invalid file type!');
//   }
// }

// // Init upload
// const upload = multer({
//   storage: storage,
//   limits: {
//     fileSize: 1024 * 1024 * 50, // 50MB limit
//   },
//   fileFilter: (req, file, cb) => {
//     checkFileType(file, cb);
//   },
// }).single('file');

// module.exports = upload;


// const multer = require('multer');


// const path = require('path');
// const fs = require('fs');

// // Set storage engine
// const storage = multer.diskStorage({
//   destination: (req, file, cb) => {
//     try {
//       const userId = req.user.id;
//       const folderName = req.params.folderName || 'defaultFolder'; // Provide a default folder name if not present
//       const userFolder = path.join(__dirname, `../uploads/${userId}`);
//       const folderPath = path.join(userFolder, folderName);

//       // Create the user folder if it doesn't exist
//       if (!fs.existsSync(userFolder)) {
//         fs.mkdirSync(userFolder);
//       }

//       // Create the folder if it doesn't exist
//       if (!fs.existsSync(folderPath)) {
//         fs.mkdirSync(folderPath);
//       }

//       cb(null, folderPath);
//     } catch (error) {
//       cb(error, null);
//     }
//   },
//   filename: (req, file, cb) => {
//     cb(null, file.originalname);
//   },
// });

// // Check file type
// function checkFileType(file, cb) {
//   // Allowed extensions
//   const filetypes = /jpeg|jpg|png|gif|pdf|doc|docx|txt/;
//   // Check the extension
//   const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
//   // Check the mime type
//   const mimetype = filetypes.test(file.mimetype);

//   if (mimetype && extname) {
//     return cb(null, true);
//   } else {
//     cb('Error: Invalid file type!');
//   }
// }

// // Init upload
// const upload = multer({
//   storage: storage,
//   limits: {
//     fileSize: 1024 * 1024 * 50, // 50MB limit
//   },
//   fileFilter: (req, file, cb) => {
//     checkFileType(file, cb);
//   },
// }).single('file');

// module.exports = upload;


// const multer = require('multer');
// const path = require('path');
// const fs = require('fs');

// // Set storage engine
// const storage = multer.diskStorage({
//   destination: (req, file, cb) => {
//     try {
//       const userId = req.user.id;
//       const folderName = req.params.folderName;
//       const userFolder = path.join(__dirname, `../uploads/${userId}`);
//       const folderPath = path.join(userFolder, folderName);

//       // Create the user folder if it doesn't exist
//       if (!fs.existsSync(userFolder)) {
//         fs.mkdirSync(userFolder);
//       }

//       // Create the folder if it doesn't exist
//       if (!fs.existsSync(folderPath)) {
//         fs.mkdirSync(folderPath);
//       }

//       cb(null, folderPath);
//     } catch (error) {
//       cb(error, null);
//     }
//   },
//   filename: (req, file, cb) => {
//     cb(null, file.originalname);
//   },
// });

// // Check file type
// function checkFileType(file, cb) {
//   // Allowed extensions
//   const filetypes = /jpeg|jpg|png|gif|pdf|doc|docx|txt/;
//   // Check the extension
//   const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
//   // Check the mime type
//   const mimetype = filetypes.test(file.mimetype);

//   if (mimetype && extname) {
//     return cb(null, true);
//   } else {
//     cb('Error: Invalid file type!');
//   }
// }

// // Init upload
// const uploadMiddleware = multer({
//   storage: storage,
//   limits: {
//     fileSize: 1024 * 1024 * 50, // 50MB limit
//   },
//   fileFilter: (req, file, cb) => {
//     checkFileType(file, cb);
//   },
// }).single('file');

// module.exports = uploadMiddleware;




// const multer = require('multer');
// const path = require('path');
// const fs = require('fs');

// // Set storage engine
// const storage = multer.diskStorage({
//   destination: (req, file, cb) => {
//     const userId = req.user.id;
//     const folderName = req.params.folderName;
//     const userFolder = path.join(__dirname, `../uploads/${userId}`);
//     const folderPath = path.join(userFolder, folderName);

//     // Create the user folder if it doesn't exist
//     if (!fs.existsSync(userFolder)) {
//       fs.mkdirSync(userFolder);
//     }

//     // Create the folder if it doesn't exist
//     if (!fs.existsSync(folderPath)) {
//       fs.mkdirSync(folderPath);
//     }

//     cb(null, folderPath);
//   },
//   filename: (req, file, cb) => {
//     cb(null, file.originalname);
//   },
// });

// // Check file type
// function checkFileType(file, cb) {
//   // Allowed extensions
//   const filetypes = /jpeg|jpg|png|gif|pdf|doc|docx|txt/;
//   // Check the extension
//   const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
//   // Check the mime type
//   const mimetype = filetypes.test(file.mimetype);

//   if (mimetype && extname) {
//     return cb(null, true);
//   } else {
//     cb('Error: Invalid file type!');
//   }
// }

// // Init upload
// const upload = multer({
//   storage: storage,
//   limits: {
//     fileSize: 1024 * 1024 * 50, // 50MB limit
//   },
//   fileFilter: (req, file, cb) => {
//     checkFileType(file, cb);
//   },
// }).single('file');

// module.exports = upload;


// const multer = require('multer');
// const path = require('path');
// const fs = require('fs');

// // Set storage engine
// const storage = multer.diskStorage({
//   destination: (req, file, cb) => {
//     const userId = req.user.id;
//     const folderName = req.params.folderName;
//     const userFolder = path.join(__dirname, `../uploads/${userId}`);
//     const folderPath = path.join(userFolder, folderName);

//     // Create the user folder if it doesn't exist
//     if (!fs.existsSync(userFolder)) {
//       fs.mkdirSync(userFolder);
//     }

//     // Create the folder if it doesn't exist
//     if (!fs.existsSync(folderPath)) {
//       fs.mkdirSync(folderPath);
//     }

//     cb(null, folderPath);
//   },
//   filename: (req, file, cb) => {
//     cb(null, file.originalname);
//   },
// });

// // Check file type
// function checkFileType(file, cb) {
//   // Allowed extensions
//   const filetypes = /jpeg|jpg|png|gif|pdf|doc|docx|txt/;
//   // Check the extension
//   const extname = filetypes.test(path.extname(file.originalname).toLowerCase());
//   // Check the mime type
//   const mimetype = filetypes.test(file.mimetype);

//   if (mimetype && extname) {
//     return cb(null, true);
//   } else {
//     cb('Error: Invalid file type!');
//   }
// }

// // Init upload
// const upload = multer({
//   storage: storage,
//   limits: {
//     fileSize: 1024 * 1024 * 50, // 50MB limit
//   },
//   fileFilter: (req, file, cb) => {
//     checkFileType(file, cb);
//   },
// }).single('file');

// module.exports = upload;
